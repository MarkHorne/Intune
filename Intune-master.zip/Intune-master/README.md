# Intune

Just a collection of Intune scripts

All scripts are provided "AS IS" with no liability and should always be tested in a test environment before used in production!
